class Pandavas extends Bharatvanshi{
    void obey(){
        System.out.println("PANDAVAS OBEY");
    }
    void kind(){
        System.out.println("PANDAVAS ARE KIND");
    }
}