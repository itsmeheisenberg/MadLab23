abstract class Bharatvanshi{
     void fighters(){
         System.out.println("Both were fighters.");
     }
     abstract void kind();
     abstract void obey();
}