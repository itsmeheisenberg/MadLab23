/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		Lake_duck ld=new Lake_duck();
		Red_head_duck rhd=new Red_head_duck();
		Wooden_duck w=new Wooden_duck();
		Rubber_duck r=new Rubber_duck();
		
		ld.swim();
		r.fly();
		rhd.quack();
	}
}
