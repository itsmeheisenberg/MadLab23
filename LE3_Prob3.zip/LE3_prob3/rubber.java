class Rubber_duck extends Duck implements flyable{
    public void fly()
    {
        System.out.println("I can fly");
    }
}