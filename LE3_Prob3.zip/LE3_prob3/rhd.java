class Red_head_duck extends Duck implements quackable{
   
    public void quack()
    {
        System.out.println("i quack");
    }
}